// Option 2 - jQuery Smooth Scroll

// $('.navbar a').on('click', function (e) {
// .navbar a : select the parameter
// .on('click') : choose event
// function(e) : event function
//     if (this.hash !== '') {
// If this 'hash' is not EMPTY, we have to prevent the default action.
//         e.preventDefault();

//         const hash = this.hash;
// make 'hash' a variable.

//         $('html, body').animate({
//             scrollTop: $(hash).offset().top
// choose the 'scrollTop method
// choose 'hash' and offset
//         }, 800); //set the speed for 800 mili-seconds

//     }
// });

// Option 3 - SmoothScroll Script using 'SmoothScroll library'
const Scroll = new SmoothScroll('.navbar a[href*="#"]', {
    speed: 800
});

